﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyagorlazs
{
    public class Class1
    {
        String nev;
        String datum;
        String tantargy;
        int jegy;
    }
}
